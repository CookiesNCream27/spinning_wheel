import React from "react";
import PropTypes from "prop-types";
import "./SpinningWheel.css";

class SpinningWheel extends React.Component {
  constructor(props) {
    super(props);
    function randPoint() {
      return Math.floor(Math.random() * 100 + 50);
    }
    this.state = {
      color: [
        "#FECF5D",
        "#02BD4C",
        "#00D3D7",
        "#3F5F92",
        "#D9445A",
        "#FF983B",
        "#498551",
        "#C33BFD"
      ],
      label: [
        randPoint(),
        randPoint(),
        randPoint(),
        randPoint(),
        randPoint(),
        randPoint(),
        randPoint(),
        randPoint()
      ],
      slices: 0,
      sliceDeg: 0,
      deg: 360,
      speed: 0,
      slowdownRand: false,
      ctx: null,
      width: null,
      center: null,
      isSpin: false,
      lock: false
    };
  }

  componentDidMount() {
    this.updateCanvas();
  }

  updateCanvas = () => {
    const { color, label, deg } = this.state;
    const refCanvas = this.refs.canvas;

    const canvas = {
      slices: color.length,
      sliceDeg: 360 / color.length,
      center: refCanvas.width / 2,
      ctx: refCanvas.getContext("2d"),
      width: refCanvas.width,
      label,
      deg,
      color
    };

    this.drawWheel(canvas);
    this.drawBtn(canvas);
  };

  deg2rad = deg => {
    return (deg * Math.PI) / 180;
  };

  drawSlice = ({ deg, color, ctx, center, width, sliceDeg }) => {
    ctx.beginPath();
    ctx.fillStyle = color;
    ctx.strokeStyle = "#ffffff";
    ctx.moveTo(center, center);
    ctx.arc(
      center,
      center,
      width / 2,
      this.deg2rad(deg),
      this.deg2rad(deg + sliceDeg)
    );
    ctx.lineTo(center, center);
    ctx.fill();
  };

  drawText = (deg, text, ctx, center) => {
    ctx.save();
    ctx.translate(center, center);
    ctx.rotate(this.deg2rad(deg));
    ctx.fillStyle = "#fff";
    ctx.font = "bold 30px sans-serif";
    ctx.fillText(text, 160, 10);
    ctx.restore();
  };

  drawArrow = ctx => {
    ctx.beginPath();
    ctx.moveTo(210, 10);
    ctx.lineTo(280, 10);
    ctx.lineTo(246, 40);
    ctx.closePath();
    ctx.fillStyle = "#e11930";
    ctx.fill();
    ctx.strokeStyle = "white";
    ctx.stroke();
    ctx.lineWidth = 10;
  };

  drawWheel = canvas => {
    const { color, label, deg, slices, sliceDeg, center, ctx, width } = canvas;
    ctx.clearRect(0, 0, center, center);

    for (var i = 0; i < slices; i++) {
      console.log(color[i], deg, ctx, center, width, sliceDeg);
      this.drawSlice({ color: color[i], deg, ctx, center, width, sliceDeg });
      ctx.strokeStyle = "white";
      ctx.stroke();
      ctx.lineWidth = 10;

      this.drawText(deg + sliceDeg / 2, label[i], ctx, center);

      this.drawArrow(ctx);

      this.setState({
        deg: deg + sliceDeg
      });
    }
  };

  drawBtn = canvas => {
    const { center, ctx } = canvas;

    ctx.beginPath();
    ctx.arc(center, center, 85, 0, 2 * Math.PI);
    ctx.lineWidth = 15;
    ctx.stroke();
    ctx.fillStyle = "white";
    ctx.fill();
    ctx.font = "bold 50px lato";
    ctx.fillStyle = "darkred";
    ctx.fillText("SPIN", center - 55, center + 20);
  };

  spin() {
    const {
      deg,
      speed,
      isSpin,
      slowdownRand,
      sliceDeg,
      slices,
      label,
      lock
    } = this.state;
    let finalDeg = deg + speed;
    finalDeg %= 360;
    this.setState({
      deg: finalDeg
    });

    if (isSpin) {
      this.setState({
        speed: speed + 1 * 0.1
      });

      if (!lock) {
        this.setState({
          lock: true,
          slowdownRand: Math.random() * (1.0 - 0.95) + 950
        });
      }
      this.setState({
        speed: speed > 0.2 ? speed * slowdownRand : 0
      });
    }

    if (lock && !speed) {
      var ai = Math.floor(((360 - deg - 90) % 360) / sliceDeg);
      ai = (slices + ai) % slices;
      return alert("You got:\n" + label[ai]);
    }
  }

  getMousePos(canvas, event) {
    const rect = canvas.getBoundingClientRect();
    return {
      x: event.clientX - rect.left,
      y: event.clientY - rect.top
    };
  }

  isInside(pos, rect) {
    return (
      pos.x > rect.x &&
      pos.x < rect.x + rect.width &&
      pos.y > rect.y &&
      pos.y < rect.y + rect.height
    );
  }

  clicked(evt) {
    console.log("pas lu klik dia masuk gak ke function ini");
    const button = {
      x: 137,
      y: 116,
      width: 100,
      height: 100
    };

    const mousePos = this.getMousePos(this.refs.canvas, evt);

    if (this.isInside(mousePos, button)) {
      requestAnimationFrame(this.spin);
      alert("bisa");
    } else {
      alert("clicked outside");
    }

    console.log(mousePos);
    console.log(button);
  }

  render() {
    return (
      <div className="wheel">
        <canvas
          className="canvas"
          ref="canvas"
          width={500}
          height={500}
          onClick={e => this.clicked(e)}
        />
      </div>
    );
  }
}

SpinningWheel.propTypes = {
  btnClicked: PropTypes.func
};

const PointContainer = () => {
  return <div className="pointContainer" />;
};

const WheelToken = () => {
  return <div className="wheelTokenContainer">Token :</div>;
};

const WheelContainer = () => {
  return (
    <div className="wheelContainer">
      {/* <PointContainer /> */}
      <SpinningWheel />
      <WheelToken />
    </div>
  );
};

export default WheelContainer;
